package com.infinity.android

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MainController : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_controller)
    }
}