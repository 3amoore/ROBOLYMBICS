# Arduino controller


## Screenshots

Home Screen
![HomeScreen](https://github.com/iMegz/Robolympics/blob/master/Images/appHomePage.png?raw=true)

Controller Screen
![ControllerScreen](https://github.com/iMegz/Robolympics/blob/master/Images/appController.png?raw=true)

Bluetooth connect Screen
![ControllerScreen](https://github.com/iMegz/Robolympics/blob/master/Images/appBTConnect.png?raw=true)

