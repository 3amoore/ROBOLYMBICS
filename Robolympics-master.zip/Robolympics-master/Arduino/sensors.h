#include "constants.h"
#include <Arduino.h>

void scan();
void scanTest();
float distance(int dir);
void trig(int pinNumber);
void sensorsSetup();
