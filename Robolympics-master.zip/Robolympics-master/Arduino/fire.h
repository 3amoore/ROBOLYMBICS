#include "constants.h"
#include <Arduino.h>

void fireSetup();
void fire();
