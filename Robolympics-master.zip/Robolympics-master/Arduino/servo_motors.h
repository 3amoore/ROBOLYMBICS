#include "constants.h"
#include <Arduino.h>
#include <Servo.h>

void servoSetup();
void servo2Up();
void servo2Down();
void servo1Movement(int y);
void jaw(int openOrClose);
//void openGrip();
//void closeGrip();
